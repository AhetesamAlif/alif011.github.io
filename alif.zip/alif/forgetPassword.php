<!DOCTYPE html>
<html>
<?php
include "HE.php";
?>
<head>
	<title>forget password</title>
</head>
<body>
	<form method="post" action="#">
		<fieldset style="width: 300px">
			<legend>FORGET PASSWORD</legend>
			Enter Email:<input type="email" name="email"><br>
			<hr><br>
			<input type="submit" name="submit" value="submit">
		</fieldset>
	</form>	
	

</body>
</html>