<!DOCTYPE html>
<?php
include "HE2.php";
?>
<html>

<head>
	<title>change profile</title>
</head>
<body>
	<div class="dashboard_right">
		Account<br>
		<hr>
		<ul>
	<li><a href="loggedInDashboard.php">Dashboard</a></li>
	<li><a href="viewProfile.php">View Profile</a></li>
	<li><a href="EditProfile.php">Edit Profile</a></li>
	<li><a href="CHangeProfilePicture.php">Change Profile Picture</a></li>
	<li><a href="changePassword.php">Change Password</a></li>
	<li><a href="logout.php">Logout</a></li>	
</ul>

	</div>


	
</body>
</html>