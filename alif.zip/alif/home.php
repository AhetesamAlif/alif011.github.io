<!DOCTYPE html>
<?php
include "HE.php";
?>
<html>
<head>
	<title>home</title>
</head>
<body>

	<p>Welcome o Xcompany</p>

</body>
</html>